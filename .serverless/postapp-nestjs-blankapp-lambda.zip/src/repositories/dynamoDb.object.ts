export class DynamoDbObject {
  id: string;
  title: string;
}
