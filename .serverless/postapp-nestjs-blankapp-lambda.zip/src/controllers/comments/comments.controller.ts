import { Controller } from '@nestjs/common';

@Controller('comments')
export class CommentsController {}
